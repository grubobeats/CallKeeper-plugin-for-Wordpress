# CallKeeper plugin for Wordpress
CallKeeper for WordPress

Authors page: http://www.givemejobtoday.com

# Instructions:

1. Download "CallKeeper for Wordpress" plugin
2. From "Settings" open "CallKeeper plugin"
3. Copy hash from CallKeeper admin page to our plug in input
4. Click "Submit script"

Ready! You submitted code to your Wordpress site!
