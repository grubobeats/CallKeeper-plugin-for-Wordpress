=== Plugin Name ===
Contributors: Vladan Paunovic
Tags: callkeeper, callback, feedback, contact, form, contact form, chat, livechat, marketing, split
Requires at least: 3.0.1
Tested up to: 4.3
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

All CallKeeper widgets in one plugin.
Plugin developed to make your job easier. just install it and add code of CallKeeper widget.

== Installation ==

This section describes how to install the plugin and get it working.

1. Download "CallKeeper for Wordpress" plugin
2. From "Settings" open "CallKeeper plugin"
3. Copy hash from CallKeeper admin page to our plug in input
4. Click "Submit script"

Ready! You submitted code to your Wordpress site!
